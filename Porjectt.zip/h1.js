// Dark mode toggle
const toggleBtn = document.getElementById("toggleMode");
const body = document.body;

toggleBtn.addEventListener("click", () => {
  body.classList.toggle("dark");
  toggleBtn.textContent = body.classList.contains("dark") ? "☀️ Light Mode" : "🌙 Dark Mode";
});

// Typing effect
const text = "I am a passionate and creative BCA student specializing in frontend development. I love crafting responsive, user-friendly websites using modern web technologies like HTML5, CSS3, and JavaScript. My goal is to continuously improve and build elegant solutions for real-world problems. I also enjoy designing personal portfolios and experimenting with UI animations and interactivity.";
let index = 0;
const speed = 35;

function typeText() {
  const target = document.getElementById("autoText");
  if (!target) return;
  if (index < text.length) {
    target.innerHTML += text.charAt(index);
    index++;
    setTimeout(typeText, speed);
  }
}
window.addEventListener("DOMContentLoaded", typeText);
